/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *btnAddItem;
    QPushButton *btnUpdateItem;
    QPushButton *btnAvailableItems;
    QPushButton *btnSoldItems;
    QPushButton *btnReport;
    QLabel *label;
    QPushButton *btnExpiredItems;
    QPushButton *btnSpoiledItem;
    QPushButton *btnReturnItems;
    QPushButton *btnFindItem;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(381, 300);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName("centralWidget");
        btnAddItem = new QPushButton(centralWidget);
        btnAddItem->setObjectName("btnAddItem");
        btnAddItem->setGeometry(QRect(30, 10, 100, 70));
        QFont font;
        font.setPointSize(11);
        btnAddItem->setFont(font);
        btnUpdateItem = new QPushButton(centralWidget);
        btnUpdateItem->setObjectName("btnUpdateItem");
        btnUpdateItem->setGeometry(QRect(140, 10, 100, 70));
        btnUpdateItem->setFont(font);
        btnAvailableItems = new QPushButton(centralWidget);
        btnAvailableItems->setObjectName("btnAvailableItems");
        btnAvailableItems->setGeometry(QRect(140, 90, 100, 70));
        btnAvailableItems->setFont(font);
        btnSoldItems = new QPushButton(centralWidget);
        btnSoldItems->setObjectName("btnSoldItems");
        btnSoldItems->setGeometry(QRect(250, 90, 100, 70));
        btnSoldItems->setFont(font);
        btnReport = new QPushButton(centralWidget);
        btnReport->setObjectName("btnReport");
        btnReport->setGeometry(QRect(250, 170, 100, 70));
        btnReport->setFont(font);
        label = new QLabel(centralWidget);
        label->setObjectName("label");
        label->setGeometry(QRect(120, 260, 141, 20));
        QFont font1;
        font1.setPointSize(10);
        label->setFont(font1);
        btnExpiredItems = new QPushButton(centralWidget);
        btnExpiredItems->setObjectName("btnExpiredItems");
        btnExpiredItems->setGeometry(QRect(30, 90, 100, 70));
        btnExpiredItems->setFont(font);
        btnSpoiledItem = new QPushButton(centralWidget);
        btnSpoiledItem->setObjectName("btnSpoiledItem");
        btnSpoiledItem->setGeometry(QRect(30, 170, 100, 70));
        btnSpoiledItem->setFont(font);
        btnReturnItems = new QPushButton(centralWidget);
        btnReturnItems->setObjectName("btnReturnItems");
        btnReturnItems->setGeometry(QRect(140, 170, 100, 70));
        btnReturnItems->setFont(font);
        btnFindItem = new QPushButton(centralWidget);
        btnFindItem->setObjectName("btnFindItem");
        btnFindItem->setGeometry(QRect(250, 10, 100, 70));
        btnFindItem->setFont(font);
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Grocery Store Manager 1.0", nullptr));
        btnAddItem->setText(QCoreApplication::translate("MainWindow", "Add\n"
" Item", nullptr));
        btnUpdateItem->setText(QCoreApplication::translate("MainWindow", "Update\n"
"Item", nullptr));
        btnAvailableItems->setText(QCoreApplication::translate("MainWindow", "Available \n"
" Items", nullptr));
        btnSoldItems->setText(QCoreApplication::translate("MainWindow", "Sold\n"
"Items", nullptr));
        btnReport->setText(QCoreApplication::translate("MainWindow", "Report", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Project By CppBuzz.com", nullptr));
        btnExpiredItems->setText(QCoreApplication::translate("MainWindow", "Expired \n"
" Items", nullptr));
        btnSpoiledItem->setText(QCoreApplication::translate("MainWindow", "Spoiled \n"
" Items", nullptr));
        btnReturnItems->setText(QCoreApplication::translate("MainWindow", "Return \n"
" Items", nullptr));
        btnFindItem->setText(QCoreApplication::translate("MainWindow", "Find\n"
"Item", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

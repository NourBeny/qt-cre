/********************************************************************************
** Form generated from reading UI file 'updateitem.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATEITEM_H
#define UI_UPDATEITEM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_UpdateItem
{
public:
    QLineEdit *txtId;
    QLabel *label_2;
    QComboBox *cmbStatus;
    QLabel *label;
    QPushButton *pushButton;
    QLabel *lblInfo;

    void setupUi(QDialog *UpdateItem)
    {
        if (UpdateItem->objectName().isEmpty())
            UpdateItem->setObjectName("UpdateItem");
        UpdateItem->setWindowModality(Qt::WindowModal);
        UpdateItem->resize(252, 148);
        txtId = new QLineEdit(UpdateItem);
        txtId->setObjectName("txtId");
        txtId->setGeometry(QRect(120, 10, 113, 20));
        QFont font;
        font.setPointSize(10);
        txtId->setFont(font);
        label_2 = new QLabel(UpdateItem);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 40, 81, 16));
        label_2->setFont(font);
        cmbStatus = new QComboBox(UpdateItem);
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->setObjectName("cmbStatus");
        cmbStatus->setGeometry(QRect(120, 40, 111, 22));
        cmbStatus->setFont(font);
        label = new QLabel(UpdateItem);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 10, 91, 16));
        label->setFont(font);
        pushButton = new QPushButton(UpdateItem);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(80, 110, 75, 30));
        pushButton->setFont(font);
        lblInfo = new QLabel(UpdateItem);
        lblInfo->setObjectName("lblInfo");
        lblInfo->setGeometry(QRect(70, 80, 131, 16));

        retranslateUi(UpdateItem);

        QMetaObject::connectSlotsByName(UpdateItem);
    } // setupUi

    void retranslateUi(QDialog *UpdateItem)
    {
        UpdateItem->setWindowTitle(QCoreApplication::translate("UpdateItem", "Update Any Item", nullptr));
        label_2->setText(QCoreApplication::translate("UpdateItem", "Set Status", nullptr));
        cmbStatus->setItemText(0, QCoreApplication::translate("UpdateItem", "Expired", nullptr));
        cmbStatus->setItemText(1, QCoreApplication::translate("UpdateItem", "Available", nullptr));
        cmbStatus->setItemText(2, QCoreApplication::translate("UpdateItem", "Returned", nullptr));
        cmbStatus->setItemText(3, QCoreApplication::translate("UpdateItem", "Sold", nullptr));
        cmbStatus->setItemText(4, QCoreApplication::translate("UpdateItem", "Spoiled", nullptr));

        label->setText(QCoreApplication::translate("UpdateItem", "Enter Item ID", nullptr));
        pushButton->setText(QCoreApplication::translate("UpdateItem", "Update", nullptr));
        lblInfo->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class UpdateItem: public Ui_UpdateItem {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATEITEM_H

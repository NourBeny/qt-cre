/********************************************************************************
** Form generated from reading UI file 'additem.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDITEM_H
#define UI_ADDITEM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AddItem
{
public:
    QPushButton *btnAdd;
    QLabel *label;
    QLineEdit *txtName;
    QLineEdit *txtQuantity;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *txtDOP;
    QLabel *label_4;
    QLineEdit *txtDOS;
    QLabel *label_5;
    QLineEdit *txtSellingPrice;
    QLabel *label_6;
    QLineEdit *txtPurchasePrice;
    QLabel *label_7;
    QComboBox *cmbStatus;
    QLabel *lblInfo;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;

    void setupUi(QDialog *AddItem)
    {
        if (AddItem->objectName().isEmpty())
            AddItem->setObjectName("AddItem");
        AddItem->setWindowModality(Qt::WindowModal);
        AddItem->resize(843, 313);
        AddItem->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 0, 127);\n"
"font: 700 10pt \"Georgia\";\n"
"color:rgb(255, 255, 255);"));
        AddItem->setInputMethodHints(Qt::ImhExclusiveInputMask);
        btnAdd = new QPushButton(AddItem);
        btnAdd->setObjectName("btnAdd");
        btnAdd->setGeometry(QRect(360, 160, 141, 41));
        QFont font;
        font.setFamilies({QString::fromUtf8("Georgia")});
        font.setPointSize(10);
        font.setBold(true);
        font.setItalic(false);
        btnAdd->setFont(font);
        btnAdd->setStyleSheet(QString::fromUtf8("color:black;"));
        label = new QLabel(AddItem);
        label->setObjectName("label");
        label->setGeometry(QRect(10, 250, 121, 16));
        label->setFont(font);
        txtName = new QLineEdit(AddItem);
        txtName->setObjectName("txtName");
        txtName->setGeometry(QRect(70, 250, 113, 20));
        txtName->setFont(font);
        txtQuantity = new QLineEdit(AddItem);
        txtQuantity->setObjectName("txtQuantity");
        txtQuantity->setGeometry(QRect(370, 220, 113, 20));
        txtQuantity->setFont(font);
        label_2 = new QLabel(AddItem);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(210, 220, 121, 16));
        label_2->setFont(font);
        label_3 = new QLabel(AddItem);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(210, 250, 121, 16));
        label_3->setFont(font);
        txtDOP = new QLineEdit(AddItem);
        txtDOP->setObjectName("txtDOP");
        txtDOP->setGeometry(QRect(370, 280, 113, 20));
        txtDOP->setFont(font);
        label_4 = new QLabel(AddItem);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(210, 280, 121, 16));
        label_4->setFont(font);
        txtDOS = new QLineEdit(AddItem);
        txtDOS->setObjectName("txtDOS");
        txtDOS->setGeometry(QRect(690, 220, 113, 20));
        txtDOS->setFont(font);
        label_5 = new QLabel(AddItem);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(530, 220, 121, 16));
        label_5->setFont(font);
        txtSellingPrice = new QLineEdit(AddItem);
        txtSellingPrice->setObjectName("txtSellingPrice");
        txtSellingPrice->setGeometry(QRect(690, 250, 113, 20));
        txtSellingPrice->setFont(font);
        label_6 = new QLabel(AddItem);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(530, 250, 121, 16));
        label_6->setFont(font);
        txtPurchasePrice = new QLineEdit(AddItem);
        txtPurchasePrice->setObjectName("txtPurchasePrice");
        txtPurchasePrice->setGeometry(QRect(690, 280, 113, 20));
        txtPurchasePrice->setFont(font);
        label_7 = new QLabel(AddItem);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(530, 280, 121, 16));
        label_7->setFont(font);
        cmbStatus = new QComboBox(AddItem);
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->setObjectName("cmbStatus");
        cmbStatus->setGeometry(QRect(370, 250, 111, 22));
        cmbStatus->setStyleSheet(QString::fromUtf8("color:black;"));
        lblInfo = new QLabel(AddItem);
        lblInfo->setObjectName("lblInfo");
        lblInfo->setGeometry(QRect(330, 120, 191, 20));
        lblInfo->setStyleSheet(QString::fromUtf8("border-radius:10px;\n"
"font: 9 pt \"Viner Hand ITC\";"));
        label_8 = new QLabel(AddItem);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(0, -11, 841, 71));
        label_8->setStyleSheet(QString::fromUtf8("font: 20pt \"Forte\";"));
        label_9 = new QLabel(AddItem);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(30, 60, 311, 141));
        label_10 = new QLabel(AddItem);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(520, 60, 301, 141));

        retranslateUi(AddItem);

        QMetaObject::connectSlotsByName(AddItem);
    } // setupUi

    void retranslateUi(QDialog *AddItem)
    {
        AddItem->setWindowTitle(QCoreApplication::translate("AddItem", "Add an Item", nullptr));
        btnAdd->setText(QCoreApplication::translate("AddItem", "ADD", nullptr));
        label->setText(QCoreApplication::translate("AddItem", "Name", nullptr));
        txtName->setText(QString());
        label_2->setText(QCoreApplication::translate("AddItem", "Quantity", nullptr));
        label_3->setText(QCoreApplication::translate("AddItem", "Status", nullptr));
        label_4->setText(QCoreApplication::translate("AddItem", "Date of Purchase", nullptr));
        label_5->setText(QCoreApplication::translate("AddItem", "Date of Sell", nullptr));
        label_6->setText(QCoreApplication::translate("AddItem", "Selling Price", nullptr));
        label_7->setText(QCoreApplication::translate("AddItem", "Purchase Price", nullptr));
        cmbStatus->setItemText(0, QCoreApplication::translate("AddItem", "Available", nullptr));
        cmbStatus->setItemText(1, QCoreApplication::translate("AddItem", "Expired", nullptr));
        cmbStatus->setItemText(2, QCoreApplication::translate("AddItem", "Sold", nullptr));
        cmbStatus->setItemText(3, QCoreApplication::translate("AddItem", "Return", nullptr));
        cmbStatus->setItemText(4, QCoreApplication::translate("AddItem", "Spoiled", nullptr));

        lblInfo->setText(QCoreApplication::translate("AddItem", ".", nullptr));
        label_8->setText(QCoreApplication::translate("AddItem", "              Its Time to add some new Article !!!", nullptr));
        label_9->setText(QCoreApplication::translate("AddItem", "TextLabel", nullptr));
        label_10->setText(QCoreApplication::translate("AddItem", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddItem: public Ui_AddItem {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDITEM_H

/********************************************************************************
** Form generated from reading UI file 'finditem.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDITEM_H
#define UI_FINDITEM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_FindItem
{
public:
    QPushButton *btnFind;
    QLineEdit *txtValue;
    QGroupBox *groupBox;
    QRadioButton *rdoName;
    QRadioButton *rdoId;
    QRadioButton *rdoQuantity;
    QRadioButton *rdoSellingPrice;
    QTableView *tableView;
    QLabel *label;

    void setupUi(QDialog *FindItem)
    {
        if (FindItem->objectName().isEmpty())
            FindItem->setObjectName("FindItem");
        FindItem->resize(516, 328);
        FindItem->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(59, 168, 255, 155), stop:1 rgba(255, 255, 255, 255));"));
        btnFind = new QPushButton(FindItem);
        btnFind->setObjectName("btnFind");
        btnFind->setGeometry(QRect(340, 70, 81, 41));
        btnFind->setStyleSheet(QString::fromUtf8("font: 12pt \"Tahoma\";"));
        txtValue = new QLineEdit(FindItem);
        txtValue->setObjectName("txtValue");
        txtValue->setGeometry(QRect(50, 69, 241, 41));
        groupBox = new QGroupBox(FindItem);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(0, 110, 521, 51));
        rdoName = new QRadioButton(groupBox);
        rdoName->setObjectName("rdoName");
        rdoName->setGeometry(QRect(10, 20, 61, 17));
        rdoId = new QRadioButton(groupBox);
        rdoId->setObjectName("rdoId");
        rdoId->setGeometry(QRect(140, 20, 61, 17));
        rdoQuantity = new QRadioButton(groupBox);
        rdoQuantity->setObjectName("rdoQuantity");
        rdoQuantity->setGeometry(QRect(270, 20, 81, 17));
        rdoSellingPrice = new QRadioButton(groupBox);
        rdoSellingPrice->setObjectName("rdoSellingPrice");
        rdoSellingPrice->setGeometry(QRect(380, 20, 111, 17));
        tableView = new QTableView(FindItem);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(10, 170, 481, 141));
        label = new QLabel(FindItem);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 521, 51));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 0);\n"
"\n"
"font: 14pt \"VCR OSD Mono\";\n"
"border-radius:5px;"));

        retranslateUi(FindItem);

        QMetaObject::connectSlotsByName(FindItem);
    } // setupUi

    void retranslateUi(QDialog *FindItem)
    {
        FindItem->setWindowTitle(QCoreApplication::translate("FindItem", "Find Items", nullptr));
        btnFind->setText(QCoreApplication::translate("FindItem", "Find", nullptr));
        groupBox->setTitle(QCoreApplication::translate("FindItem", "Select Criteria", nullptr));
        rdoName->setText(QCoreApplication::translate("FindItem", "Name", nullptr));
        rdoId->setText(QCoreApplication::translate("FindItem", "Id", nullptr));
        rdoQuantity->setText(QCoreApplication::translate("FindItem", "Quantity", nullptr));
        rdoSellingPrice->setText(QCoreApplication::translate("FindItem", "Selling Price", nullptr));
        label->setText(QCoreApplication::translate("FindItem", "  What are u Looking for in my Shop ??", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FindItem: public Ui_FindItem {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDITEM_H

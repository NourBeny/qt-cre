/********************************************************************************
** Form generated from reading UI file 'updateitem.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATEITEM_H
#define UI_UPDATEITEM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_UpdateItem
{
public:
    QLineEdit *txtId;
    QLabel *label_2;
    QComboBox *cmbStatus;
    QLabel *label;
    QPushButton *pushButton;
    QLabel *lblInfo;

    void setupUi(QDialog *UpdateItem)
    {
        if (UpdateItem->objectName().isEmpty())
            UpdateItem->setObjectName("UpdateItem");
        UpdateItem->setWindowModality(Qt::WindowModal);
        UpdateItem->resize(416, 124);
        UpdateItem->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 255, 255);\n"
"font: 9pt \"Georgia\";\n"
"border-radius: 5 px;\n"
""));
        txtId = new QLineEdit(UpdateItem);
        txtId->setObjectName("txtId");
        txtId->setGeometry(QRect(150, 20, 113, 20));
        QFont font;
        font.setFamilies({QString::fromUtf8("Georgia")});
        font.setPointSize(9);
        font.setBold(false);
        font.setItalic(false);
        txtId->setFont(font);
        txtId->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_2 = new QLabel(UpdateItem);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(10, 50, 81, 16));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Georgia")});
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setItalic(false);
        label_2->setFont(font1);
        label_2->setStyleSheet(QString::fromUtf8("\n"
"font: 10pt \"Georgia\";\n"
"border-radius:5px;"));
        cmbStatus = new QComboBox(UpdateItem);
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->addItem(QString());
        cmbStatus->setObjectName("cmbStatus");
        cmbStatus->setGeometry(QRect(130, 50, 111, 22));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Georgia")});
        font2.setPointSize(12);
        font2.setBold(false);
        font2.setItalic(false);
        cmbStatus->setFont(font2);
        cmbStatus->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"font: 12pt \"Georgia\";\n"
"border-radius:5px;"));
        label = new QLabel(UpdateItem);
        label->setObjectName("label");
        label->setGeometry(QRect(10, 20, 131, 16));
        label->setFont(font2);
        label->setStyleSheet(QString::fromUtf8("\n"
"font: 12pt \"Georgia\";\n"
"border-radius:5px;"));
        pushButton = new QPushButton(UpdateItem);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(280, 20, 101, 51));
        pushButton->setFont(font2);
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 0);\n"
"font: 12pt \"Georgia\";\n"
"border-radius:5px;"));
        lblInfo = new QLabel(UpdateItem);
        lblInfo->setObjectName("lblInfo");
        lblInfo->setGeometry(QRect(150, 90, 131, 16));

        retranslateUi(UpdateItem);

        QMetaObject::connectSlotsByName(UpdateItem);
    } // setupUi

    void retranslateUi(QDialog *UpdateItem)
    {
        UpdateItem->setWindowTitle(QCoreApplication::translate("UpdateItem", "Update Article", nullptr));
        label_2->setText(QCoreApplication::translate("UpdateItem", "Set Status", nullptr));
        cmbStatus->setItemText(0, QCoreApplication::translate("UpdateItem", "Expired", nullptr));
        cmbStatus->setItemText(1, QCoreApplication::translate("UpdateItem", "Available", nullptr));
        cmbStatus->setItemText(2, QCoreApplication::translate("UpdateItem", "Returned", nullptr));
        cmbStatus->setItemText(3, QCoreApplication::translate("UpdateItem", "Sold", nullptr));
        cmbStatus->setItemText(4, QCoreApplication::translate("UpdateItem", "Spoiled", nullptr));

        label->setText(QCoreApplication::translate("UpdateItem", "Enter Item ID", nullptr));
        pushButton->setText(QCoreApplication::translate("UpdateItem", "Update", nullptr));
        lblInfo->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class UpdateItem: public Ui_UpdateItem {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATEITEM_H

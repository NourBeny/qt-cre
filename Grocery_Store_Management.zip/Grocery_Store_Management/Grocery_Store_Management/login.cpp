#include "login.h"
#include "ui_login.h"
#include<QMessageBox>
#include <QPixmap>

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);


    QPixmap pix ("C:/Users/HP/Desktop/12.jpg");
    int w = ui->label_5->width();
    int h = ui->label_5->width();


    ui->label_5->setPixmap(pix.scaled(h,w,Qt::KeepAspectRatio));
    Mwin = new MainWindow(this);
}

Login::~Login()
{
    delete ui;
}

void Login::on_Login_2_clicked()
{
    QString username = ui->lineEdit_u->text();
    QString password = ui->lineEdit_2->text();
     db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("C:/Users/HP/Desktop/Grocery_Store_Management/Grocery_Store_Management/mini_projet_c++.sqlite");
        QSqlQuery q;
        if(!db.open())
            ui->label_4->setText("database is not connected");
        else
            ui->label_4->setText("database connected");
        //query.prepare("select * from user where ussername = '"+username+"' and password = '"+password+"'");
        if(q.exec("select * from user where username = '"+username+"' and password = '"+password+"'")){

            if(q.next()){

                 Mwin->show();

            }
            else{
           // ui->label_3->setText("coka");
            qDebug() <<"read was not successful ";
            }

        }
}


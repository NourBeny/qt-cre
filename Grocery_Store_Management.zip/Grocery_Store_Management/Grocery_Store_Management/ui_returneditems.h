/********************************************************************************
** Form generated from reading UI file 'returneditems.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RETURNEDITEMS_H
#define UI_RETURNEDITEMS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ReturnedItems
{
public:
    QTableView *tableView;

    void setupUi(QDialog *ReturnedItems)
    {
        if (ReturnedItems->objectName().isEmpty())
            ReturnedItems->setObjectName("ReturnedItems");
        ReturnedItems->resize(320, 240);
        ReturnedItems->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 255, 127);"));
        tableView = new QTableView(ReturnedItems);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(0, 10, 321, 221));
        tableView->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 255);"));

        retranslateUi(ReturnedItems);

        QMetaObject::connectSlotsByName(ReturnedItems);
    } // setupUi

    void retranslateUi(QDialog *ReturnedItems)
    {
        ReturnedItems->setWindowTitle(QCoreApplication::translate("ReturnedItems", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ReturnedItems: public Ui_ReturnedItems {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RETURNEDITEMS_H

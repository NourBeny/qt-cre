/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QGroupBox *groupBox;
    QPushButton *Login_2;
    QLineEdit *lineEdit_u;
    QLineEdit *lineEdit_2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_5;
    QLabel *label_4;

    void setupUi(QDialog *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName("Login");
        Login->resize(651, 381);
        Login->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.399194 rgba(0, 0, 255, 226), stop:1 rgba(255, 255, 255, 255));"));
        groupBox = new QGroupBox(Login);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(220, 40, 421, 271));
        Login_2 = new QPushButton(groupBox);
        Login_2->setObjectName("Login_2");
        Login_2->setGeometry(QRect(180, 200, 93, 29));
        Login_2->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(255, 255, 0);"));
        lineEdit_u = new QLineEdit(groupBox);
        lineEdit_u->setObjectName("lineEdit_u");
        lineEdit_u->setGeometry(QRect(182, 60, 161, 25));
        lineEdit_u->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 0);"));
        lineEdit_2 = new QLineEdit(groupBox);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(180, 110, 161, 25));
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 0);"));
        label = new QLabel(groupBox);
        label->setObjectName("label");
        label->setGeometry(QRect(40, 60, 81, 20));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-radius : 10px;"));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(40, 120, 81, 20));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-radius : 10px;"));
        label_5 = new QLabel(Login);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(30, 50, 171, 251));
        label_4 = new QLabel(Login);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(362, 340, 141, 20));

        retranslateUi(Login);

        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QDialog *Login)
    {
        Login->setWindowTitle(QCoreApplication::translate("Login", "Login", nullptr));
        groupBox->setTitle(QCoreApplication::translate("Login", "Sign up", nullptr));
        Login_2->setText(QCoreApplication::translate("Login", "Login", nullptr));
        label->setText(QCoreApplication::translate("Login", " username", nullptr));
        label_2->setText(QCoreApplication::translate("Login", "  password", nullptr));
        label_5->setText(QString());
        label_4->setText(QCoreApplication::translate("Login", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H

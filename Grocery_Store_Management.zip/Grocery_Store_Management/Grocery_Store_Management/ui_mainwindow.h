/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *btnAddItem;
    QPushButton *btnUpdateItem;
    QPushButton *btnAvailableItems;
    QPushButton *btnSoldItems;
    QPushButton *btnReport;
    QLabel *label;
    QPushButton *btnExpiredItems;
    QPushButton *btnSpoiledItem;
    QPushButton *btnReturnItems;
    QPushButton *btnFindItem;
    QLabel *label_2;
    QLabel *label_5;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(793, 496);
        QFont font;
        font.setFamilies({QString::fromUtf8("Georgia")});
        MainWindow->setFont(font);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));\n"
"color: rgb(0, 0, 0);"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName("centralWidget");
        centralWidget->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0, cy:0, angle:135, stop:0 rgba(255, 255, 0, 69), stop:0.375 rgba(255, 255, 0, 69), stop:0.423533 rgba(251, 255, 0, 145), stop:0.45 rgba(247, 255, 0, 208), stop:0.477581 rgba(255, 244, 71, 130), stop:0.518717 rgba(255, 218, 71, 130), stop:0.55 rgba(255, 255, 0, 255), stop:0.57754 rgba(255, 203, 0, 130), stop:0.625 rgba(255, 255, 0, 69), stop:1 rgba(255, 255, 0, 69));\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));"));
        btnAddItem = new QPushButton(centralWidget);
        btnAddItem->setObjectName("btnAddItem");
        btnAddItem->setGeometry(QRect(630, 80, 141, 70));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Georgia")});
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setItalic(false);
        btnAddItem->setFont(font1);
        btnAddItem->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(255, 0, 0);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;\n"
"border: 10px ;\n"
" cursor: pointer;"));
        btnUpdateItem = new QPushButton(centralWidget);
        btnUpdateItem->setObjectName("btnUpdateItem");
        btnUpdateItem->setGeometry(QRect(630, 170, 141, 70));
        btnUpdateItem->setFont(font1);
        btnUpdateItem->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(255, 0, 0);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;"));
        btnAvailableItems = new QPushButton(centralWidget);
        btnAvailableItems->setObjectName("btnAvailableItems");
        btnAvailableItems->setGeometry(QRect(200, 360, 141, 41));
        btnAvailableItems->setFont(font1);
        btnAvailableItems->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 255);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;"));
        btnSoldItems = new QPushButton(centralWidget);
        btnSoldItems->setObjectName("btnSoldItems");
        btnSoldItems->setGeometry(QRect(370, 360, 121, 41));
        btnSoldItems->setFont(font1);
        btnSoldItems->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 255);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;"));
        btnReport = new QPushButton(centralWidget);
        btnReport->setObjectName("btnReport");
        btnReport->setGeometry(QRect(350, 420, 141, 51));
        btnReport->setFont(font1);
        btnReport->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 255);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;"));
        label = new QLabel(centralWidget);
        label->setObjectName("label");
        label->setGeometry(QRect(120, 260, 141, 20));
        QFont font2;
        font2.setPointSize(10);
        label->setFont(font2);
        btnExpiredItems = new QPushButton(centralWidget);
        btnExpiredItems->setObjectName("btnExpiredItems");
        btnExpiredItems->setGeometry(QRect(30, 360, 131, 41));
        btnExpiredItems->setFont(font1);
        btnExpiredItems->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 255);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;"));
        btnSpoiledItem = new QPushButton(centralWidget);
        btnSpoiledItem->setObjectName("btnSpoiledItem");
        btnSpoiledItem->setGeometry(QRect(510, 360, 131, 41));
        btnSpoiledItem->setFont(font1);
        btnSpoiledItem->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 255);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;"));
        btnReturnItems = new QPushButton(centralWidget);
        btnReturnItems->setObjectName("btnReturnItems");
        btnReturnItems->setGeometry(QRect(650, 360, 121, 41));
        btnReturnItems->setFont(font1);
        btnReturnItems->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 255);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;"));
        btnFindItem = new QPushButton(centralWidget);
        btnFindItem->setObjectName("btnFindItem");
        btnFindItem->setGeometry(QRect(630, 260, 141, 71));
        btnFindItem->setFont(font1);
        btnFindItem->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);\n"
"border-radius : 20px;\n"
"font: 700 10pt \"Georgia\";\n"
"border-color : white ;"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(10, 70, 611, 281));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(0, 0, 791, 71));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Magneto")});
        font3.setPointSize(28);
        font3.setBold(true);
        font3.setItalic(false);
        label_5->setFont(font3);
        label_5->setStyleSheet(QString::fromUtf8("font: 700 28pt \"Magneto\";\n"
"color: rgb(255, 0, 0);"));
        MainWindow->setCentralWidget(centralWidget);
        label_5->raise();
        btnAddItem->raise();
        btnUpdateItem->raise();
        btnAvailableItems->raise();
        btnSoldItems->raise();
        btnReport->raise();
        label->raise();
        btnExpiredItems->raise();
        btnSpoiledItem->raise();
        btnReturnItems->raise();
        btnFindItem->raise();
        label_2->raise();

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Welcome to the store of stores", nullptr));
        btnAddItem->setText(QCoreApplication::translate("MainWindow", "Add Item", nullptr));
        btnUpdateItem->setText(QCoreApplication::translate("MainWindow", "Update Item", nullptr));
        btnAvailableItems->setText(QCoreApplication::translate("MainWindow", "Available Items", nullptr));
        btnSoldItems->setText(QCoreApplication::translate("MainWindow", "Sold Items", nullptr));
        btnReport->setText(QCoreApplication::translate("MainWindow", "Report", nullptr));
        label->setText(QString());
        btnExpiredItems->setText(QCoreApplication::translate("MainWindow", "Expired Items", nullptr));
        btnSpoiledItem->setText(QCoreApplication::translate("MainWindow", "Spoiled Items", nullptr));
        btnReturnItems->setText(QCoreApplication::translate("MainWindow", "Return Items", nullptr));
        btnFindItem->setText(QCoreApplication::translate("MainWindow", "Find Item", nullptr));
        label_2->setText(QString());
        label_5->setText(QCoreApplication::translate("MainWindow", "        Welcome To My Store", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
